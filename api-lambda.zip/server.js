const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
require('dotenv').config();

/**
 * @fileoverview Express REST API for the file compression service.
 *
 * Provides endpoints for:
 *   - Initializing multipart S3 uploads with presigned URLs
 *   - Completing uploads and triggering Fargate compression tasks
 *   - Polling job status from DynamoDB
 *   - One-time download with token validation
 *
 * Environment Variables:
 *   PORT           – Server port (default: 3001)
 *   CORS_ORIGIN    – Allowed CORS origin (default: http://localhost:5173)
 *   AWS_REGION     – AWS region (default: us-east-1)
 *   S3_BUCKET      – S3 bucket name
 *   DYNAMODB_TABLE – DynamoDB table name (default: file-compressor-jobs)
 *   ECS_CLUSTER    – ECS cluster name (default: file-compressor-cluster)
 *   ECS_TASK_DEF   – ECS task definition name (default: file-compressor-task)
 *   ECS_SUBNETS    – Comma-separated subnet IDs for Fargate tasks
 *   ECS_SECURITY_GROUPS – Comma-separated security group IDs (optional)
 */

const express = require('express');
const cors = require('cors');
const jobsRouter = require('./routes/jobs');

const app = express();
const PORT = process.env.PORT || 3001;
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:5173';

// ---------------------------------------------------------------------------
// Middleware
// ---------------------------------------------------------------------------

const fs = require('fs');
const distPath = path.join(__dirname, '../../frontend/dist');

app.use(cors({
  origin: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(express.json({ limit: '1mb' }));

// Request logging
app.use((req, _res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] [INFO] [API] ${req.method} ${req.path}`);
  next();
});

// Serve frontend static assets if available
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

/** Health check */
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

/** Job routes */
app.use('/api/jobs', jobsRouter);

// SPA fallback for frontend client-side routing
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  const indexPath = path.join(distPath, 'index.html');
  if (fs.existsSync(indexPath)) {
    return res.sendFile(indexPath);
  }
  next();
});

// ---------------------------------------------------------------------------
// Error handling
// ---------------------------------------------------------------------------

// 404 handler
app.use((_req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Global error handler
app.use((err, _req, res, _next) => {
  const timestamp = new Date().toISOString();
  console.error(`[${timestamp}] [ERROR] [API] ${err.message}`);
  console.error(err.stack);

  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    error: err.message || 'Internal server error',
  });
});

// ---------------------------------------------------------------------------
// Start server (only if executed directly, not imported by Lambda)
// ---------------------------------------------------------------------------

if (require.main === module) {
  app.listen(PORT, () => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] [INFO] [API] Server running on port ${PORT}`);
    console.log(`[${timestamp}] [INFO] [API] CORS origin: ${CORS_ORIGIN}`);
    console.log(`[${timestamp}] [INFO] [API] S3 bucket: ${process.env.S3_BUCKET || '(not set)'}`);
    console.log(`[${timestamp}] [INFO] [API] DynamoDB table: ${process.env.DYNAMODB_TABLE || 'file-compressor-jobs'}`);
  });
}

module.exports = app;
