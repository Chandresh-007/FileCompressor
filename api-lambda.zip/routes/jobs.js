'use strict';

/**
 * @fileoverview Job management routes for the file compression API.
 *
 * Endpoints:
 *   POST /api/jobs/init              – Create job + multipart presigned URLs
 *   POST /api/jobs/:jobId/complete-upload – Complete multipart + trigger Fargate
 *   GET  /api/jobs/:jobId/status      – Poll job status
 *   POST /api/jobs/:jobId/download    – One-time download with token
 */

const { Router } = require('express');
const { v4: uuidv4 } = require('uuid');
const {
  S3Client,
  CreateMultipartUploadCommand,
  UploadPartCommand,
  CompleteMultipartUploadCommand,
  HeadObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
} = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const { ECSClient, RunTaskCommand } = require('@aws-sdk/client-ecs');

const router = Router();

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

const REGION = process.env.AWS_REGION || 'us-east-1';
const BUCKET = process.env.S3_BUCKET || 'file-compressor-dev-20260916';
const TABLE = process.env.DYNAMODB_TABLE || 'file-compressor-jobs';
const ECS_CLUSTER = process.env.ECS_CLUSTER || 'file-compressor-cluster';
const ECS_TASK_DEF = process.env.ECS_TASK_DEF || 'file-compressor-task';
const ECS_SUBNETS = (process.env.ECS_SUBNETS || '').split(',').filter(Boolean);
const ECS_SECURITY_GROUPS = (process.env.ECS_SECURITY_GROUPS || '').split(',').filter(Boolean);
const MAX_FILE_SIZE = 800 * 1024 * 1024; // 800 MB
const PART_SIZE = 10 * 1024 * 1024; // 10 MB
const PRESIGNED_URL_EXPIRY = 3600; // 1 hour
const DOWNLOAD_URL_EXPIRY = 300; // 5 minutes
const DOWNLOAD_EXPIRY_HOURS = 2;

// ---------------------------------------------------------------------------
// AWS Clients
// ---------------------------------------------------------------------------

const s3Config = { region: REGION };
if (process.env.AWS_ENDPOINT_URL || process.env.S3_ENDPOINT) {
  s3Config.endpoint = process.env.AWS_ENDPOINT_URL || process.env.S3_ENDPOINT;
  s3Config.forcePathStyle = true;
}
const s3 = new S3Client(s3Config);

const ddbConfig = { region: REGION };
if (process.env.DYNAMODB_ENDPOINT || process.env.AWS_ENDPOINT_URL) {
  ddbConfig.endpoint = process.env.DYNAMODB_ENDPOINT || process.env.AWS_ENDPOINT_URL;
}
const ddbClient = DynamoDBDocumentClient.from(new DynamoDBClient(ddbConfig), {
  marshallOptions: { removeUndefinedValues: true },
});
const ecs = new ECSClient({ region: REGION });

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Structured logger.
 *
 * @param {'INFO'|'WARN'|'ERROR'} level
 * @param {string} message
 */
function log(level, message) {
  console.log(`[${new Date().toISOString()}] [${level}] [JOBS] ${message}`);
}

/**
 * Creates an async Express error with a status code.
 *
 * @param {number} statusCode
 * @param {string} message
 * @returns {Error}
 */
function httpError(statusCode, message) {
  const err = new Error(message);
  err.statusCode = statusCode;
  return err;
}

// ---------------------------------------------------------------------------
// POST /api/jobs/init
// ---------------------------------------------------------------------------

/**
 * Creates a new compression job:
 *   1. Validates filename and fileSize
 *   2. Generates a jobId (UUID)
 *   3. Starts an S3 multipart upload
 *   4. Generates presigned URLs for each part
 *   5. Creates a DynamoDB record with status "uploading"
 *
 * Request body: { filename: string, fileSize: number, parts: number }
 * Response: { jobId, uploadId, uploadUrls: string[] }
 */
router.post('/init', async (req, res, next) => {
  try {
    const { filename, fileSize, parts } = req.body;

    // Validate inputs
    if (!filename || typeof filename !== 'string') {
      throw httpError(400, 'Missing or invalid "filename"');
    }
    if (!fileSize || typeof fileSize !== 'number' || fileSize <= 0) {
      throw httpError(400, 'Missing or invalid "fileSize"');
    }
    if (fileSize > MAX_FILE_SIZE) {
      throw httpError(400, `File size ${fileSize} exceeds maximum of ${MAX_FILE_SIZE} bytes (800 MB)`);
    }
    if (!parts || typeof parts !== 'number' || parts < 1) {
      throw httpError(400, 'Missing or invalid "parts" (must be >= 1)');
    }

    const jobId = uuidv4();
    const sanitizedFilename = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
    const inputKey = `uploads/${jobId}/${sanitizedFilename}`;
    const outputKey = `compressed/${jobId}/${sanitizedFilename}.7z`;

    log('INFO', `Creating job ${jobId} for "${sanitizedFilename}" (${fileSize} bytes, ${parts} parts)`);

    // Start S3 multipart upload
    const createResp = await s3.send(new CreateMultipartUploadCommand({
      Bucket: BUCKET,
      Key: inputKey,
    }));
    const uploadId = createResp.UploadId;

    // Generate presigned URLs for each part
    const uploadUrls = [];
    for (let i = 1; i <= parts; i++) {
      const cmd = new UploadPartCommand({
        Bucket: BUCKET,
        Key: inputKey,
        UploadId: uploadId,
        PartNumber: i,
      });
      const url = await getSignedUrl(s3, cmd, { expiresIn: PRESIGNED_URL_EXPIRY });
      uploadUrls.push(url);
    }

    // Create DynamoDB record
    await ddbClient.send(new PutCommand({
      TableName: TABLE,
      Item: {
        jobId,
        status: 'uploading',
        progress: 0,
        filename: sanitizedFilename,
        inputFileKey: inputKey,
        outputFileKey: outputKey,
        inputSize: fileSize,
        outputSize: 0,
        compressionRatio: null,
        downloadToken: null,
        downloadUsed: false,
        uploadId,
        createdAt: new Date().toISOString(),
        expiresAt: null,
        errorMessage: null,
        // TTL field for DynamoDB (24 hours from now, in epoch seconds)
        ttl: Math.floor(Date.now() / 1000) + 86400,
      },
    }));

    log('INFO', `Job ${jobId} created. Upload ID: ${uploadId}. ${parts} presigned URLs generated.`);

    res.status(201).json({ jobId, uploadId, uploadUrls });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// POST /api/jobs/:jobId/complete-upload
// ---------------------------------------------------------------------------

/**
 * Completes the S3 multipart upload and triggers Fargate compression.
 *
 * Request body: { uploadId: string, parts: [{ PartNumber: number, ETag: string }] }
 * Response: { jobId, status: "queued" }
 */
router.post('/:jobId/complete-upload', async (req, res, next) => {
  try {
    const { jobId } = req.params;
    const { uploadId, parts } = req.body;

    if (!uploadId || !Array.isArray(parts) || parts.length === 0) {
      throw httpError(400, 'Missing "uploadId" or "parts" array');
    }

    // Fetch the job to get S3 keys
    const jobResp = await ddbClient.send(new GetCommand({
      TableName: TABLE,
      Key: { jobId },
    }));

    if (!jobResp.Item) {
      throw httpError(404, `Job ${jobId} not found`);
    }

    const job = jobResp.Item;
    log('INFO', `Completing upload for job ${jobId}`);

    // Complete multipart upload
    await s3.send(new CompleteMultipartUploadCommand({
      Bucket: BUCKET,
      Key: job.inputFileKey,
      UploadId: uploadId,
      MultipartUpload: {
        Parts: parts.map((p) => ({
          PartNumber: p.PartNumber,
          ETag: p.ETag,
        })),
      },
    }));

    // Verify file size via HeadObject
    const headResp = await s3.send(new HeadObjectCommand({
      Bucket: BUCKET,
      Key: job.inputFileKey,
    }));

    if (headResp.ContentLength > MAX_FILE_SIZE) {
      throw httpError(400, `Uploaded file size (${headResp.ContentLength}) exceeds 800 MB limit`);
    }

    // Update DynamoDB status to "queued"
    await ddbClient.send(new UpdateCommand({
      TableName: TABLE,
      Key: { jobId },
      UpdateExpression: 'SET #s = :s, inputSize = :sz',
      ExpressionAttributeNames: { '#s': 'status' },
      ExpressionAttributeValues: {
        ':s': 'queued',
        ':sz': headResp.ContentLength,
      },
    }));

    // Trigger Fargate task (or dev/mock if configured)
    if (ECS_CLUSTER === 'local' || process.env.NODE_ENV === 'test') {
      log('INFO', `Running in local/test mode; skipping ECS task for job ${jobId}`);
    } else {
      if (ECS_SUBNETS.length === 0) {
        log('ERROR', `Cannot trigger Fargate task for job ${jobId}: ECS_SUBNETS is not configured`);
        await ddbClient.send(new UpdateCommand({
          TableName: TABLE,
          Key: { jobId },
          UpdateExpression: 'SET #s = :s, errorMessage = :e',
          ExpressionAttributeNames: { '#s': 'status' },
          ExpressionAttributeValues: {
            ':s': 'failed',
            ':e': 'ECS subnets not configured in environment (ECS_SUBNETS).',
          },
        }));
        throw httpError(500, 'ECS subnets not configured in server environment');
      }

      try {
        const taskParams = {
          cluster: ECS_CLUSTER,
          taskDefinition: ECS_TASK_DEF,
          launchType: 'FARGATE',
          overrides: {
            containerOverrides: [{
              name: 'file-compressor',
              environment: [
                { name: 'S3_BUCKET', value: BUCKET },
                { name: 'INPUT_FILE_KEY', value: job.inputFileKey },
                { name: 'OUTPUT_FILE_KEY', value: job.outputFileKey },
                { name: 'JOB_ID', value: jobId },
                { name: 'AWS_REGION', value: REGION },
                { name: 'DYNAMODB_TABLE', value: TABLE },
              ],
            }],
          },
          networkConfiguration: {
            awsvpcConfiguration: {
              subnets: ECS_SUBNETS,
              assignPublicIp: 'ENABLED',
              ...(ECS_SECURITY_GROUPS.length > 0 && { securityGroups: ECS_SECURITY_GROUPS }),
            },
          },
        };

        await ecs.send(new RunTaskCommand(taskParams));
        log('INFO', `Fargate task triggered for job ${jobId}`);
      } catch (ecsErr) {
        log('ERROR', `Failed to trigger Fargate task for job ${jobId}: ${ecsErr.message}`);
        // Update status to failed if we can't start Fargate
        await ddbClient.send(new UpdateCommand({
          TableName: TABLE,
          Key: { jobId },
          UpdateExpression: 'SET #s = :s, errorMessage = :e',
          ExpressionAttributeNames: { '#s': 'status' },
          ExpressionAttributeValues: {
            ':s': 'failed',
            ':e': `Failed to start compression task: ${ecsErr.message}`,
          },
        }));
        throw httpError(500, 'Failed to start compression task');
      }
    }

    res.json({ jobId, status: 'queued' });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// GET /api/jobs/:jobId/status
// ---------------------------------------------------------------------------

/**
 * Returns the current status of a job from DynamoDB.
 *
 * Response: { jobId, status, progress, inputSize, outputSize, compressionRatio,
 *             downloadToken?, expiresAt?, filename, createdAt, errorMessage? }
 */
router.get('/:jobId/status', async (req, res, next) => {
  try {
    const { jobId } = req.params;

    const resp = await ddbClient.send(new GetCommand({
      TableName: TABLE,
      Key: { jobId },
    }));

    if (!resp.Item) {
      throw httpError(404, `Job ${jobId} not found`);
    }

    const job = resp.Item;

    // Check if download has expired
    if (job.status === 'done' && job.expiresAt && new Date(job.expiresAt) < new Date()) {
      // Mark as expired
      await ddbClient.send(new UpdateCommand({
        TableName: TABLE,
        Key: { jobId },
        UpdateExpression: 'SET #s = :s',
        ExpressionAttributeNames: { '#s': 'status' },
        ExpressionAttributeValues: { ':s': 'expired' },
      }));
      job.status = 'expired';
    }

    res.json({
      jobId: job.jobId,
      status: job.status,
      progress: job.progress || 0,
      inputSize: job.inputSize || 0,
      outputSize: job.outputSize || 0,
      compressionRatio: job.compressionRatio || null,
      downloadToken: (job.status === 'done' && !job.downloadUsed) ? job.downloadToken : null,
      downloadUsed: job.downloadUsed || false,
      expiresAt: job.expiresAt || null,
      filename: job.filename || null,
      createdAt: job.createdAt || null,
      errorMessage: job.errorMessage || null,
    });
  } catch (err) {
    next(err);
  }
});

// ---------------------------------------------------------------------------
// POST /api/jobs/:jobId/download
// ---------------------------------------------------------------------------

/**
 * Generates a one-time presigned download URL.
 *
 * Validates the download token, checks it hasn't been used,
 * generates a 5-minute presigned URL, marks as downloaded,
 * and schedules S3 file deletion.
 *
 * Request body: { downloadToken: string }
 * Response: { downloadUrl: string }
 */
router.post('/:jobId/download', async (req, res, next) => {
  try {
    const { jobId } = req.params;
    const { downloadToken } = req.body;

    if (!downloadToken) {
      throw httpError(400, 'Missing "downloadToken"');
    }

    // Get job from DynamoDB
    const resp = await ddbClient.send(new GetCommand({
      TableName: TABLE,
      Key: { jobId },
    }));

    if (!resp.Item) {
      throw httpError(404, `Job ${jobId} not found`);
    }

    const job = resp.Item;

    // Validate token
    if (job.downloadToken !== downloadToken) {
      throw httpError(403, 'Invalid download token');
    }

    // Check if already downloaded
    if (job.downloadUsed) {
      throw httpError(403, 'This file has already been downloaded and deleted.');
    }

    // Check if expired
    if (job.expiresAt && new Date(job.expiresAt) < new Date()) {
      throw httpError(410, 'Download link expired. File has been deleted.');
    }

    // Generate 5-minute presigned download URL
    const downloadUrl = await getSignedUrl(
      s3,
      new GetObjectCommand({
        Bucket: BUCKET,
        Key: job.outputFileKey,
        ResponseContentDisposition: `attachment; filename="${job.filename}.7z"`,
      }),
      { expiresIn: DOWNLOAD_URL_EXPIRY }
    );

    // Mark download as used
    await ddbClient.send(new UpdateCommand({
      TableName: TABLE,
      Key: { jobId },
      UpdateExpression: 'SET downloadUsed = :u, #s = :s',
      ExpressionAttributeNames: { '#s': 'status' },
      ExpressionAttributeValues: {
        ':u': true,
        ':s': 'downloaded',
      },
    }));

    log('INFO', `Download generated for job ${jobId}. Scheduling S3 cleanup...`);

    // Clean up input file immediately since it is already compressed
    setImmediate(async () => {
      try {
        await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: job.inputFileKey }));
        log('INFO', `Deleted input file: ${job.inputFileKey}`);
      } catch (err) {
        log('WARN', `Failed to delete input file: ${err.message}`);
      }
    });

    // Schedule compressed file deletion after 10 minutes to allow user download to complete
    setTimeout(async () => {
      try {
        await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: job.outputFileKey }));
        log('INFO', `Deleted compressed file after download window: ${job.outputFileKey}`);
      } catch (err) {
        log('WARN', `Failed to delete compressed file: ${err.message}`);
      }
    }, 10 * 60 * 1000);

    res.json({ downloadUrl });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
