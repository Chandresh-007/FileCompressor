'use strict';

const serverless = require('serverless-http');
const app = require('./server');

// Wrap Express app with serverless-http adapter for AWS Lambda & Function URL
module.exports.handler = serverless(app);
